#!/usr/bin/env sh
set -e
echo test
